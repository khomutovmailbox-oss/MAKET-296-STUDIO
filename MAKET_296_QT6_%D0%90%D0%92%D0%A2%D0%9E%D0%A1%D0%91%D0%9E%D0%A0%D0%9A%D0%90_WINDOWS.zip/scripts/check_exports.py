"""Check actual Windows Qt binary output in CI, not previews or mocks."""
from pathlib import Path
import sys, math, xml.etree.ElementTree as ET
from PIL import Image
import fitz
folder=Path(sys.argv[1])
pdf=folder/'test_296.pdf'
png=folder/'test_296.png'
svg=folder/'test_296.svg'
for path in [pdf,png,svg]:
    assert path.exists() and path.stat().st_size > 500, f'Empty or missing: {path}'
with fitz.open(pdf) as doc:
    assert len(doc)==1
    rect=doc[0].rect
    width_mm=rect.width/72*25.4
    height_mm=rect.height/72*25.4
    assert abs(width_mm-296)<0.4, f'PDF width={width_mm}mm'
    assert abs(height_mm-465)<0.4, f'PDF height={height_mm}mm'
with Image.open(png) as im:
    assert im.mode in ('RGBA','P'), f'No PNG alpha: {im.mode}'
    rgba=im.convert('RGBA')
    w,h=rgba.size
    assert abs(w - round(296/25.4*300)) <= 1
    assert abs(h - round(465/25.4*300)) <= 1
    assert rgba.getpixel((0,0))[3] == 0, 'PNG corner should be transparent'
    alpha=rgba.getchannel('A')
    assert alpha.getbbox(), 'Expected vector lettering in rendered PNG'
    dpi=im.info.get('dpi',(0,0))
    assert abs(dpi[0]-300)<2 and abs(dpi[1]-300)<2, f'PNG dpi={dpi}'
root=ET.parse(svg).getroot()
assert root.attrib.get('width','').startswith('296'), root.attrib
assert root.attrib.get('width','').endswith('mm'), root.attrib
assert root.attrib.get('height','').endswith('mm'), root.attrib
print('OK: authentic Qt 6 Windows export PDF, PNG alpha+300dpi and SVG, 296mm width')
