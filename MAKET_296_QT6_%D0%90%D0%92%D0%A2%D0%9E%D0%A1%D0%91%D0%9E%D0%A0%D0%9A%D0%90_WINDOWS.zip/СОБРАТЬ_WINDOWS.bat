@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ================= MAKET 296 - Qt 6 =================
echo Требуется Qt 6.4+ для MSVC 2022 64-bit или MinGW 64-bit,
echo CMake, Ninja и подходящий C++ компилятор.
echo Запускайте в Qt 6 Command Prompt или Developer PowerShell.
echo.
where cmake >nul 2>&1 || (echo ОШИБКА: cmake не найден. & pause & exit /b 1)
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 (echo ОШИБКА: не найден Qt 6 SDK или компилятор. & pause & exit /b 1)
cmake --build build --config Release --parallel
if errorlevel 1 (echo ОШИБКА компиляции. & pause & exit /b 1)
if not exist "build\MAKET_296_QT6.exe" (echo Не найден EXE. & pause & exit /b 1)
if not exist "dist" mkdir "dist"
copy /Y "build\MAKET_296_QT6.exe" "dist\MAKET_296_QT6.exe" >nul
where windeployqt >nul 2>&1 || (echo windeployqt не найден: загрузите Qt bin в PATH & pause & exit /b 1)
windeployqt --release --compiler-runtime "dist\MAKET_296_QT6.exe"
if errorlevel 1 (echo Не удалось собрать Qt DLL рядом с EXE. & pause & exit /b 1)
echo.
echo Готово! Запускайте dist\MAKET_296_QT6.exe
echo Для переноса на другой ПК копируйте всю папку dist.
pause
