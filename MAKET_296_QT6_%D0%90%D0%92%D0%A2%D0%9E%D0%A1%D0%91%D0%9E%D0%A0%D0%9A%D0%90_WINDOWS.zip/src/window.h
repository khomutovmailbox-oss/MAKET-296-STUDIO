#pragma once
#include "model.h"
#include "renderer.h"
#include <QMainWindow>
#include <QPointer>
#include <QWidget>
class QCheckBox;class QComboBox;class QLineEdit;class QListWidget;class QPushButton;
class QScrollArea;class QSlider;class QSpinBox;class QTabWidget;class QLabel;
namespace Maket {
class Canvas : public QWidget {
    Q_OBJECT
public:
    explicit Canvas(QWidget *parent=nullptr);
    void setDesign(Design *d);
    void setScale(qreal scale);
    qreal scale()const{return scale_;}
    void setSelected(int index);
    int selected()const{return selected_;}
    void refresh();
signals:
    void selectionChanged(int index);
    void designChanged();
    void filesDropped(const QStringList &files,int startIndex);
    void replaceRequested(int index);
    void zoomRequested(int delta);
protected:
    void paintEvent(QPaintEvent *) override;
    void mousePressEvent(QMouseEvent *) override;
    void mouseMoveEvent(QMouseEvent *) override;
    void mouseReleaseEvent(QMouseEvent *) override;
    void mouseDoubleClickEvent(QMouseEvent *) override;
    void wheelEvent(QWheelEvent *) override;
    void dragEnterEvent(QDragEnterEvent *) override;
    void dropEvent(QDropEvent *) override;
private:
    int slotAt(const QPoint &point)const;
    QPointF canvasPoint(QPoint p)const;
    Design *design_=nullptr;
    ImageCache cache_;
    qreal scale_=0.70;
    int selected_=-1;
    bool dragging_=false;
    QPoint dragStart_;
    qreal shiftStartX_=0,shiftStartY_=0;
};
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent=nullptr);
private:
    Design design_;
    QWidget *left_=nullptr;
    Canvas *canvas_=nullptr;
    QScrollArea *scroller_=nullptr;
    QTabWidget *tabs_=nullptr;
    QListWidget *templates_=nullptr;
    QLineEdit *wordEdit_=nullptr,*titleEdit_=nullptr,*leftEdit_=nullptr,*rightEdit_=nullptr,*dateEdit_=nullptr,*quoteEdit_=nullptr;
    QComboBox *styleCombo_=nullptr,*fillCombo_=nullptr,*topCombo_=nullptr;
    QSpinBox *heightSpin_=nullptr;
    QSlider *brightSlider_=nullptr,*contrastSlider_=nullptr,*zoomSlider_=nullptr;
    QCheckBox *monoCheck_=nullptr;
    QLabel *slotInfo_=nullptr,*fileInfo_=nullptr,*statusSize_=nullptr;
    QPushButton *replaceButton_=nullptr,*removeButton_=nullptr;
    QWidget *posterOptions_=nullptr;
    QString projectPath_;
    bool loading_=false;
    int exportsRunning_=0;
    void buildUi();
    void createTemplates();
    void syncControls();
    void syncPhotoControls();
    void modified();
    void changePreset(int id);
    void switchMode(bool letters);
    void setPhoto(int index,const QString &file);
    void openPhotos(const QStringList &files,int startIndex);
    void replacePhoto();
    void saveProject(bool as=false);
    void openProject();
    void exportAs(const QString &extension);
    void fitCanvas();
    void setZoom(double value);
    void updateSizing();
    void statusMessage(const QString &s);
};
}
