#pragma once
#include "model.h"
#include <QHash>
#include <QImage>
#include <QPainter>
#include <QString>
namespace Maket {
class ImageCache {
public:
    QImage image(const Photo &p, bool preview);
    void clear();
private:
    QHash<QString,QImage> raw_;
    QHash<QString,QImage> corrected_;
};
class Renderer {
public:
    // Painter coordinates: 1000 units wide, (height_mm / 296) * 1000 units high.
    // Never paints a background for export: outside photos/elements is transparent.
    static void paint(QPainter &p, const Design &d, bool editorGuides=false, int selected=-1, ImageCache *cache=nullptr);
    static bool exportFile(const QString &filename, const Design &design, int dpi, QString *error=nullptr);
    static QImage preview(const Design &design,int maxWidth=560);
};
}
