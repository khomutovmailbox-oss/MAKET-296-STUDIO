#include "renderer.h"
#include <QFile>
#include <QFileInfo>
#include <QRegularExpression>
#include <QFontMetricsF>
#include <QImageReader>
#include <QPageSize>
#include <QPdfWriter>
#include <QSvgGenerator>
#include <QTransform>
#include <QtMath>
#include <algorithm>
#include <cmath>
using namespace Maket;
namespace {
qreal boardH(const Design &d){return LogicalW*d.heightMm/WidthMm;}
QRectF box(const Design&d,double x,double y,double w,double h){return QRectF(x*1000,y*boardH(d),w*1000,h*boardH(d));}
QImage load(const QString &path,bool preview){
    if(path.isEmpty()) return {};
    QImageReader reader(path);reader.setAutoTransform(true);
    if(preview){QSize s=reader.size();if(s.width()>0 && s.height()>0){
        const double factor=std::min(1.0,1050.0/std::max(s.width(),s.height()));
        if(factor<1)reader.setScaledSize(QSize(std::max(1,int(s.width()*factor)),std::max(1,int(s.height()*factor))));
    }}
    return reader.read().convertToFormat(QImage::Format_ARGB32);
}
QImage corrections(const QImage &im,const Photo &ph){
    if(im.isNull() || (!ph.mono && !ph.brightness && !ph.contrast))return im;
    QImage out=im.copy().convertToFormat(QImage::Format_ARGB32);
    int lut[256];double c=(100.0+ph.contrast)/100.0;
    for(int i=0;i<256;i++)lut[i]=qBound(0,int((i-128)*c+128+ph.brightness*2.0+.5),255);
    for(int y=0;y<out.height();y++){
        auto *px=reinterpret_cast<QRgb*>(out.scanLine(y));
        for(int x=0;x<out.width();x++){
            QRgb v=px[x];int r=qRed(v),g=qGreen(v),b=qBlue(v);
            if(ph.mono){int gray=(r*299+g*587+b*114+500)/1000;r=g=b=gray;}
            px[x]=qRgba(lut[r],lut[g],lut[b],qAlpha(v));
        }
    }
    return out;
}
void textPath(QPainter &p,const QString &text,QRectF rect,QColor color,QString family="Arial",bool outline=false,qreal fill=.94){
    if(text.trimmed().isEmpty() || rect.width()<1 || rect.height()<1)return;
    QFont f(family);f.setWeight(QFont::Black);f.setPixelSize(250);
    QPainterPath path;path.addText(QPointF(0,0),f,text);
    auto bounds=path.boundingRect();if(bounds.isEmpty())return;
    qreal sx=rect.width()/bounds.width()*fill;
    qreal sy=rect.height()/bounds.height()*fill;
    // Poster titles are intentionally stretched, matching the supplied designs.
    QTransform t;t.translate(rect.center().x(),rect.center().y());t.scale(sx,sy);t.translate(-bounds.center().x(),-bounds.center().y());
    p.save();if(outline)p.setPen(QPen(color,1.6));else p.setPen(Qt::NoPen);
    if(outline)p.setBrush(Qt::NoBrush);else p.setBrush(QBrush(color));
    p.drawPath(t.map(path));p.restore();
}
void smallText(QPainter &p,const QString &text,QRectF rect,QColor ink,bool bold=false,Qt::Alignment align=Qt::AlignCenter,qreal fraction=.50){
    if(text.trimmed().isEmpty())return;
    QFont f("Arial");f.setWeight(bold?QFont::Bold:QFont::Normal);
    int fontPx=qBound(6,int(rect.height()*fraction),90);f.setPixelSize(fontPx);
    p.save();p.setPen(ink);p.setFont(f);
    QFontMetricsF fm(f);
    // Shrink lines to their real available width instead of silently clipping.
    QStringList lines=text.split('\n');
    int maxLength=0;for(const auto &line:lines)maxLength=std::max(maxLength,int(fm.horizontalAdvance(line)));
    if (maxLength>rect.width()*.99){f.setPixelSize(qMax(6,int(fontPx*rect.width()*.99/maxLength)));p.setFont(f);}
    p.drawText(rect,int(align)|Qt::TextWordWrap,text);
    p.restore();
}
void arrows(QPainter&p,QRectF rect,QColor color,int count=5){
    p.save();p.setBrush(Qt::NoBrush);p.setPen(QPen(color,1.55,Qt::SolidLine,Qt::SquareCap,Qt::MiterJoin));
    double step=rect.width()/count;
    for(int i=0;i<count;i++){
        double x=rect.left()+step*i+step*.04;
        QPainterPath path;path.moveTo(x,rect.top()+rect.height()*.05);
        path.lineTo(x+step*.68,rect.center().y());path.lineTo(x,rect.bottom()-rect.height()*.05);
        p.drawPath(path);
    }
    p.restore();
}
void barcode(QPainter&p,QRectF rect,QColor color){
    p.save();p.setPen(Qt::NoPen);p.setBrush(color);
    double x=rect.left();int i=0;
    while(x<rect.right() && i++<180){
        int k=(i*37+i*i*11+79)%23;
        double w=1.5+k%4*.48;
        if(i%5!=0)p.drawRect(QRectF(x,rect.top(),std::min(w,rect.right()-x),rect.height()*(i%7==0?.86:1)));
        x+=w+1.25+(k%3)*.6;
    }
    p.restore();
}
void border(QPainter &p,QRectF r,QColor color,double width=1.5){
    p.save();p.setPen(QPen(color,width));p.setBrush(Qt::NoBrush);p.drawRect(r);p.restore();
}
void large(QPainter&p,const QString&s,QRectF r,QColor color,bool outline=false){textPath(p,s,r,color,"Impact",outline);}
void headline(QPainter&p,const Design&d,QRectF b,bool special=false){
    if(d.topStyle==5 || d.title.trimmed().isEmpty())return;
    auto ink=d.ink;
    switch(d.topStyle){
    case 0:large(p,d.title,b,ink);break;
    case 1:
        large(p,d.title,QRectF(b.x(),b.y(),b.width(),b.height()*.70),ink);
        large(p,d.title,QRectF(b.x(),b.y()+b.height()*.44,b.width(),b.height()*.55),ink,true);
        break;
    case 2:
        large(p,d.title,QRectF(b.x(),b.y(),b.width(),b.height()*.42),ink);
        large(p,d.title,QRectF(b.x(),b.y()+b.height()*.31,b.width(),b.height()*.42),ink,true);
        large(p,d.title,QRectF(b.x(),b.y()+b.height()*.61,b.width(),b.height()*.38),ink,true);
        break;
    case 3:
        large(p,d.title,b,ink,true);
        large(p,d.title,QRectF(b.x()+b.width()*.055,b.y()+b.height()*.53,b.width()*.89,b.height()*.44),ink);
        break;
    case 4:large(p,d.title,b,ink);break;
    default: break;
    }
    Q_UNUSED(special)
}
QRectF crop(const Photo &p,const QSize &source,QRectF destination){
    double iw=source.width(),ih=source.height();
    if(iw<1 || ih<1)return {};
    double destRatio=destination.width()/destination.height();
    double cropW=iw,cropH=ih;
    if(iw/ih>destRatio) cropW=ih*destRatio;
    else cropH=iw/destRatio;
    double zoom=qBound(1.0,p.zoom,5.0);cropW/=zoom;cropH/=zoom;
    double x=(iw-cropW)*(.5+.5*qBound(-1.0,p.shiftX,1.0));
    double y=(ih-cropH)*(.5+.5*qBound(-1.0,p.shiftY,1.0));
    return QRectF(x,y,cropW,cropH);
}
void decorations(QPainter &p,const Design &d){
    if(d.letters)return;
    QColor ink=d.ink;
    auto b=[&](double x,double y,double w,double h){return box(d,x,y,w,h);};
    auto title=[&](double x,double y,double w,double h){headline(p,d,b(x,y,w,h));};
    auto caption=[&](const QString&s,double x,double y,double w,double h,bool bold=false,Qt::Alignment a=Qt::AlignCenter,double size=.55){smallText(p,s,b(x,y,w,h),ink,bold,a,size);};
    auto dateLarge=[&](double x,double y,double w,double h){large(p,d.date,b(x,y,w,h),ink);};
    switch(d.preset){
    case 0: case 7: {
        title(.003,.003,.994,.290);
        caption(d.quote,.120,.735,.760,.110,false,Qt::AlignCenter,.36);
        arrows(p,b(.012,.859,.399,.130),ink,4);
        dateLarge(.450,.855,.536,.135);
        break;
    }
    case 1: {
        title(.003,.003,.994,.184);
        arrows(p,b(.006,.797,.384,.075),ink,6);
        large(p,d.right,b(.405,.784,.582,.096),ink);
        barcode(p,b(.014,.888,.295,.095),ink);
        caption(d.date,.018,.980,.280,.020,false,Qt::AlignCenter,.9);
        caption(d.quote,.46,.866,.520,.121,true,Qt::AlignCenter,.29);
        break;
    }
    case 2:{
        title(.005,.001,.990,.170);
        arrows(p,b(.005,.766,.510,.065),ink,6);
        large(p,d.right,b(.528,.767,.464,.078),ink);
        barcode(p,b(.015,.861,.304,.098),ink);
        caption(d.date,.035,.949,.270,.038,false,Qt::AlignLeft,.65);
        caption(d.quote,.55,.855,.438,.078,true,Qt::AlignCenter,.40);
        large(p,d.left,b(.329,.926,.584,.073),ink);
        break;
    }
    case 4:{
        title(.095,.000,.815,.161);
        caption(d.quote,.224,.818,.55,.105,false,Qt::AlignCenter,.32);
        dateLarge(.285,.928,.430,.066);
        break;
    }
    case 5:{
        border(p,b(.020,.036,.961,.924),ink,1.4);
        border(p,b(.043,.098,.260,.454),ink,1.3);
        border(p,b(.538,.088,.414,.460),ink,1.3);
        large(p,d.title,b(.315,.079,.222,.110),ink);
        caption("ID  "+d.date,.319,.180,.220,.075,true,Qt::AlignLeft,.53);
        auto rows=d.quote.split(';');
        for(int i=0;i<rows.size() && i<5;i++)caption(rows[i].trimmed(),.553,.101+i*.087,.384,.070,false,Qt::AlignLeft,.44);
        p.fillRect(b(.046,.576,.911,.080),ink);
        caption("Reason for Arrest",.052,.585,.900,.066,true,Qt::AlignCenter,.54);
        textPath(p,d.right,b(.170,.675,.655,.080),QColor("#B52328"),"Arial");
        caption("Known for being unforgettable.",.073,.772,.854,.109,false,Qt::AlignCenter,.36);
        caption(d.left,.710,.884,.235,.054,true,Qt::AlignRight,.68);
        break;
    }
    case 6:{
        border(p,b(.018,.029,.342,.903),ink,1.3);
        border(p,b(.446,.029,.342,.903),ink,1.3);
        caption(d.left,.040,.811,.296,.111,false,Qt::AlignCenter,.42);
        caption(d.right,.465,.810,.300,.111,false,Qt::AlignCenter,.42);
        break;
    }
    case 8:{
        title(.004,.001,.992,.218);
        caption("◀  ▶     2:03 / 3:09",.060,.459,.400,.069,true,Qt::AlignLeft,.45);
        p.setPen(QPen(ink,1.5));p.drawLine(b(.460,.483,.46,.001).topLeft(),b(.46,.483,.46,.001).topRight());
        large(p,d.right,b(.54,.467,.396,.079),ink);
        border(p,b(.079,.600,.840,.355),ink,1.5);
        caption(d.quote,.340,.830,.560,.100,true,Qt::AlignCenter,.45);
        break;
    }
    case 9:{
        title(.045,.003,.910,.160);
        caption(d.quote,.104,.792,.790,.100,false,Qt::AlignCenter,.38);
        dateLarge(.300,.895,.400,.090);
        break;
    }
    case 10:{
        title(.008,.003,.984,.084);
        arrows(p,b(.011,.318,.395,.033),ink,6);
        large(p,d.right,b(.479,.312,.502,.055),ink);
        caption(d.quote,.106,.353,.790,.042,false,Qt::AlignCenter,.34);
        title(.006,.386,.985,.085);
        arrows(p,b(.010,.692,.410,.030),ink,6);
        large(p,d.right,b(.460,.688,.525,.041),ink);
        caption(d.quote,.112,.740,.790,.041,false,Qt::AlignCenter,.30);
        caption("КОНДЕЙ 13",.200,.822,.600,.035,true,Qt::AlignCenter,.8);
        large(p,d.date,b(.05,.878,.900,.040),ink);
        break;
    }
    default:break;
    }
}
}
void Maket::ImageCache::clear(){raw_.clear();corrected_.clear();}
QImage Maket::ImageCache::image(const Photo &p,bool preview){
    if(!preview)return corrections(load(p.path,false),p);
    auto it=raw_.constFind(p.path);
    if(it==raw_.cend()){
        if(raw_.size()>75){raw_.clear();corrected_.clear();}
        raw_.insert(p.path,load(p.path,true));
    }
    QString key=p.path+'|'+QString::number(p.mono)+'|'+QString::number(p.brightness)+'|'+QString::number(p.contrast);
    if(!corrected_.contains(key)){
        if(corrected_.size()>48)corrected_.clear();
        corrected_.insert(key,corrections(raw_.value(p.path),p));
    }
    return corrected_.value(key);
}
void Maket::Renderer::paint(QPainter &p,const Design &d,bool guides,int selected,ImageCache *cache){
    const double H=boardH(d);
    p.save();p.setRenderHint(QPainter::Antialiasing,true);p.setRenderHint(QPainter::SmoothPixmapTransform,true);
    // No background is painted: transparent page by design.
    const auto items=slots(d);const auto glyphs=d.letters?letterPaths(d):QVector<QPainterPath>();
    // Bounded full-resolution cache for repeated photos inside letters during export.
    QHash<QString,QImage> exportImages;QStringList exportOrder;
    for(int i=0;i<items.size();i++){
        const auto &slot=items[i];
        if(i<d.photos.size() && !d.photos[i].path.isEmpty()){
            const auto &ph=d.photos[i];
            QImage photo;
            if(cache)photo=cache->image(ph,true);
            else {
                QString key=ph.path+"|"+QString::number(ph.mono)+"|"+QString::number(ph.brightness)+"|"+QString::number(ph.contrast);
                if(!exportImages.contains(key)) {
                    if(exportOrder.size()>=4)exportImages.remove(exportOrder.takeFirst());
                    exportImages.insert(key,corrections(load(ph.path,false),ph));
                    exportOrder.append(key);
                }
                photo=exportImages.value(key);
            }
            if(!photo.isNull()){
                p.save();
                QPainterPath clipping;clipping.addRect(slot.r);
                if(d.letters){
                    QPainterPath mask;
                    if(slot.mask==-2){for(const auto &g:glyphs)mask.addPath(g);}
                    else if(slot.mask>=0 && slot.mask<glyphs.size())mask=glyphs[slot.mask];
                    p.setClipPath(mask,Qt::IntersectClip);
                }
                p.setClipPath(clipping,Qt::IntersectClip);
                const QRectF source=crop(ph,photo.size(),slot.r);
                // Tiny overlap against adjacent photo slots prevents antialias hairlines.
                QRectF dest=slot.r.adjusted(-.10,-.10,.10,.10);
                p.drawImage(dest,photo,source);
                p.restore();
            }
        }
    }
    decorations(p,d);
    if(guides){
        p.save();
        p.setBrush(Qt::NoBrush);
        for(int i=0;i<items.size();i++){
            QPen pen(i==selected?QColor("#32d0b1"):QColor("#48b9cf"),i==selected?3:1.35,Qt::DashLine);
            p.setPen(pen);
            if(d.letters){
                if(items[i].mask>=0 && items[i].mask<glyphs.size())p.drawPath(glyphs[items[i].mask]);
                else if(d.letterFill==1 || d.letterFill==3){
                    QPainterPath whole;for(const auto &g:glyphs)whole.addPath(g);p.drawPath(whole);
                    if(d.letterFill==3)p.drawRect(items[i].r);
                }
            } else p.drawRect(items[i].r);
            if(items[i].mask==-1 && (i>=d.photos.size() || d.photos[i].path.isEmpty())){
                QFont font("Arial",12,QFont::DemiBold);font.setPixelSize(std::min(21.0,items[i].r.height()*.20));p.setFont(font);
                p.setPen(QColor("#299eac"));
                p.drawText(items[i].r,Qt::AlignCenter,QString::number(i+1));
            }
        }
        p.restore();
    }
    p.restore();
    Q_UNUSED(H)
}
bool Maket::Renderer::exportFile(const QString &name,const Design &d,int dpi,QString *error){
    QFileInfo file(name);const QString ext=file.suffix().toLower();
    const qreal H=boardH(d);
    auto failure=[&](const QString &message){if(error)*error=message;return false;};
    if(ext=="pdf"){
        QPdfWriter writer(name);
        writer.setResolution(dpi);
        writer.setPageSize(QPageSize(QSizeF(WidthMm,d.heightMm),QPageSize::Millimeter));
        writer.setPageMargins(QMarginsF(0,0,0,0));
        QPainter p(&writer);if(!p.isActive())return failure("Не удалось создать PDF");
        const double pxW=WidthMm/25.4*dpi;
        p.scale(pxW/LogicalW,pxW/LogicalW);
        paint(p,d,false,-1,nullptr);
        p.end();return true;
    }
    if(ext=="svg"){
        QSvgGenerator writer;
        writer.setFileName(name);writer.setSize(QSize(1000,qRound(H)));
        writer.setViewBox(QRect(0,0,1000,qRound(H)));
        writer.setResolution(96);writer.setTitle("MAKET 296 Qt6");
        QPainter p(&writer);if(!p.isActive())return failure("Не удалось создать SVG");
        paint(p,d,false,-1,nullptr);p.end();
        // QtSvgGenerator writes its dimensions in screen units by default.
        // Replace root dimensions to guarantee EXACT 296 mm in the final SVG.
        QFile file(name);
        if(file.open(QIODevice::ReadOnly)){
            QString xml=QString::fromUtf8(file.readAll());file.close();
            const int pos=xml.indexOf("<svg");
            const int end=pos>=0?xml.indexOf('>',pos):-1;
            if(end>pos){
                QString root=xml.mid(pos,end-pos+1);
                root.replace(QRegularExpression("\\bwidth=\"[^\"]+\""),"width=\"296mm\"");
                root.replace(QRegularExpression("\\bheight=\"[^\"]+\""),QString("height=\"%1mm\"").arg(d.heightMm,0,'f',3));
                xml.replace(pos,end-pos+1,root);
                if(!file.open(QIODevice::WriteOnly|QIODevice::Truncate))return failure("Не удалось установить размеры SVG");
                file.write(xml.toUtf8());file.close();
            }
        }
        return true;
    }
    if(ext=="png"){
        int w=qRound(WidthMm/25.4*dpi),h=qRound(d.heightMm/25.4*dpi);
        if(w<1 || h<1 || quint64(w)*quint64(h)>110000000ULL)return failure("Размер изображения слишком большой");
        QImage img(w,h,QImage::Format_ARGB32_Premultiplied);
        if(img.isNull())return failure("Недостаточно памяти для PNG");
        img.fill(Qt::transparent);img.setDotsPerMeterX(qRound(dpi/0.0254));img.setDotsPerMeterY(qRound(dpi/0.0254));
        QPainter p(&img);p.scale(w/LogicalW,w/LogicalW);paint(p,d,false,-1,nullptr);p.end();
        if(!img.save(name,"PNG"))return failure("Не удалось сохранить PNG");
        return true;
    }
    return failure("Поддерживаются PDF, PNG и SVG");
}
QImage Maket::Renderer::preview(const Design &d,int maxWidth){
    auto h=qRound(maxWidth*d.heightMm/WidthMm);
    QImage img(maxWidth,h,QImage::Format_ARGB32_Premultiplied);img.fill(Qt::transparent);
    QPainter p(&img);p.scale(double(maxWidth)/1000,double(maxWidth)/1000);
    ImageCache cache;paint(p,d,true,-1,&cache);p.end();return img;
}
