#include "model.h"
#include <QDir>
#include <QFileInfo>
#include <QFont>
#include <QJsonArray>
#include <QTransform>
#include <QtMath>
#include <algorithm>
using namespace Maket;

QVector<Preset> Maket::presets() {
    return {
        {0, "ONLY YOU · крупный взгляд", 305, "ONLY YOU", "", "05 04 2026", "05 04 2026", "Время летит, а мы с тобой ещё ближе стали!", 2,1,1},
        {1, "KOROTKOV · фотомозаика", 424, "KOROTKOV", "LOVE", "VIOLETTA", "14 05 2026", "Я пишу мысли про тебя только", 3,6,4},
        {2, "GIRLFRIEND · 6 фото", 465, "GIRLFRIEND", "YASHIKA", "VERIKA", "16 09 2006", "Я точил первак, сходил с ума", 1,6,4},
        {4, "VALERIA · центр + коллаж", 424, "VALERIA", "", "08 08 2024", "08 08 2024", "La-la-la-la-la", 0,0,1},
        {5, "ДОСЬЕ · карточка", 213, "TOLYA", "Tolya", "THE TAMER", "13022006", "AGE: 20 YEARS OLD;SEX: MALE;HEIGHT: 189 CM;CITY: SAINT PETERSBURG;GANG: SECTION", 0,0,0},
        {6, "ПОЛАРОИДЫ · 2 фотографии", 150, "", "Интересно, кто будет моей любимой?", "Я буду!", "", "", 5,0,0},
        {7, "ONLY YOU · двойной контур", 305, "ONLY YOU", "", "22 07 2025", "22 07 2025", "Я хочу как в кино", 1,1,1},
        {8, "МУЗЫКА · взгляд + карточка", 500, "ONLY YOU", "", "ANASTASIA", "", "THIS IS LOVE", 2,0,3},
        {9, "ДУЭТ · два портрета", 424, "YULIYA", "", "22 03 2026", "22 03 2026", "Любовь без памяти", 0,0,1},
        {10,"ULIANA · двойной монтаж", 1123,"GIRLFRIEND", "", "ULIANA", "17 02 2026", "Подари мне любовь", 1,1,3}
    };
}
const Preset* Maket::findPreset(int id) {
    // Stable storage; do not return pointers into a temporary QVector.
    static const QVector<Preset> all = presets();
    for (const auto &p: all) if (p.id == id) return &p;
    return nullptr;
}
Design Maket::defaultDesign(int preset) {
    Design d;
    if (const auto *p=findPreset(preset)) {
        d.preset=p->id;d.heightMm=p->height;d.title=p->title;d.left=p->left;
        d.right=p->right;d.date=p->date;d.quote=p->quote;d.topStyle=p->top;
        d.leftStyle=p->leftStyle;d.rightStyle=p->rightStyle;
    }
    d.photos.resize(slots(d).size());
    return d;
}
QStringList Maket::letterStyleNames() {
    return {"Impact · массивные", "Arial Black · геометричные", "Arial Rounded · мягкие", "Bahnschrift · узкие", "Georgia · классика"};
}
QStringList Maket::fillModeNames() {
    return {"1 фото на букву", "1 фото через всё слово", "4 фото на букву", "Мозаика через всё слово"};
}
QVector<QPainterPath> Maket::letterPaths(const Design &d) {
    QString word = d.word.trimmed().toUpper().left(16);
    if (word.isEmpty()) word="MOM";
    const QStringList families={"Impact","Arial Black","Arial Rounded MT Bold","Bahnschrift Condensed","Georgia"};
    QFont font(families.value(d.letterStyle,"Impact"));
    font.setWeight(QFont::Black);
    font.setPixelSize(260);
    font.setStyleStrategy(QFont::PreferAntialias);
    const int n=word.size();
    QVector<qreal> widths; qreal total=0;
    for (const auto ch:word) {
        qreal w=(ch==QLatin1Char('I')||ch==QLatin1Char('1')?0.55:
                 QString("MWЖШЩЮФ").contains(ch)?1.17:1.0);
        widths<<w;total+=w;
    }
    if (total<=0) return {};
    const double gap= n>8?4.0:9.0;
    const double space=1000-64-gap*(n-1);
    const double H=1000*d.heightMm/WidthMm;
    const double targetH = std::min(H*.77, 880.0);
    const double top = (H-targetH)/2.0;
    qreal x=32;
    QVector<QPainterPath> result;
    for (int i=0;i<n;++i) {
        qreal cw=space*widths[i]/total;
        QPainterPath native;
        native.addText(QPointF(0,0),font,QString(word[i]));
        QRectF box=native.boundingRect();
        if (!native.isEmpty() && box.width()>0 && box.height()>0) {
            QTransform transform;
            transform.translate(x,top);
            transform.scale((cw*0.97)/box.width(),targetH/box.height());
            transform.translate(-box.left(),-box.top());
            result << transform.map(native);
        } else result<<QPainterPath();
        x+=cw+gap;
    }
    return result;
}
QVector<Slot> Maket::slots(const Design &d) {
    auto R=[&d](double x,double y,double w,double h){return QRectF(1000*x,(1000*d.heightMm/WidthMm)*y,1000*w,(1000*d.heightMm/WidthMm)*h);};
    QVector<Slot> v;
    auto add=[&](double x,double y,double w,double h,int mask=-1){v.push_back({R(x,y,w,h),mask});};
    if (d.letters) {
        const auto glyphs=letterPaths(d);
        if (glyphs.isEmpty()) return v;
        QRectF all;
        for (const auto &path:glyphs) all=all.isNull()?path.boundingRect():all.united(path.boundingRect());
        switch(d.letterFill) {
        case 0:
            for (int i=0;i<glyphs.size();++i) v.push_back({glyphs[i].boundingRect(),i});
            break;
        case 1: v.push_back({all,-2});break;
        case 2:
            for (int i=0;i<glyphs.size();++i) {
                QRectF b=glyphs[i].boundingRect();
                for(int row=0;row<2;row++)for(int col=0;col<2;col++)
                    v.push_back({QRectF(b.left()+col*b.width()/2,b.top()+row*b.height()/2,b.width()/2,b.height()/2),i});
            }
            break;
        case 3: {
            int cols=qBound(3,glyphs.size()*3,16);
            for(int row=0;row<2;row++)for(int col=0;col<cols;col++)
                v.push_back({QRectF(all.left()+col*all.width()/cols,all.top()+row*all.height()/2,all.width()/cols,all.height()/2),-2});
            break;
        }
        default:break;
        }
        return v;
    }
    const double third=1.0/3;
    switch(d.preset) {
    case 0: case 7:add(0,.310,1,.371);break;
    case 1:
        add(0,.202,third,.293);add(third,.202,third,.158);add(2*third,.202,third,.293);
        add(third,.360,third,.145);add(0,.495,third,.283);add(third,.505,third,.273);add(2*third,.495,third,.283);break;
    case 2:for(int r=0;r<2;r++)for(int c=0;c<3;c++)add(c*third,.185+r*.310,third,.310);break;
    case 4:
        add(.06,.093,.44,.32);add(.5,.093,.44,.32);add(.06,.413,.44,.35);add(.5,.413,.44,.35);add(.23,.28,.54,.495);break;
    case 5:add(.051,.108,.244,.426);break;
    case 6:add(.038,.082,.286,.725);add(.463,.082,.286,.725);break;
    case 8:add(0,.245,1,.198);add(.12,.650,.18,.183);add(.30,.650,.19,.183);add(.49,.650,.19,.183);add(.68,.650,.18,.183);break;
    case 9:add(.068,.18,.432,.596);add(.5,.18,.432,.596);break;
    case 10:for(int r=0;r<2;r++)for(int c=0;c<4;c++)add(c*.25,r==0?.095:.472,.25,.211);break;
    default:add(0,.185,1,.57);break;
    }
    return v;
}
QJsonObject Maket::toJson(const Design &d,const QString &baseFolder) {
    QJsonObject root{{"format","MAKET296-Qt6"},{"version",1},{"width_mm",WidthMm},
        {"height_mm",d.heightMm},{"letters",d.letters},{"preset",d.preset},
        {"title",d.title},{"left",d.left},{"right",d.right},{"date",d.date},{"quote",d.quote},
        {"top_style",d.topStyle},{"left_style",d.leftStyle},{"right_style",d.rightStyle},
        {"ink",d.ink.name()},{"word",d.word},{"letter_style",d.letterStyle},{"letter_fill",d.letterFill}};
    QJsonArray arr; QDir base(baseFolder);
    for (const auto &p:d.photos) {
        QString src=p.path;
        if (!src.isEmpty() && QFileInfo(src).isAbsolute()) src=base.relativeFilePath(src);
        arr.append(QJsonObject{{"path",src},{"mono",p.mono},{"bright",p.brightness},
            {"contrast",p.contrast},{"zoom",p.zoom},{"shift_x",p.shiftX},{"shift_y",p.shiftY}});
    }
    root["photos"]=arr;return root;
}
bool Maket::fromJson(const QJsonObject &o,const QString &base,Design &d) {
    if (o.value("format").toString()!="MAKET296-Qt6") return false;
    Design n;
    n.letters=o.value("letters").toBool(false);n.preset=o.value("preset").toInt(2);
    if (!findPreset(n.preset)) n.preset=2;
    n.heightMm=qBound(90.0,o.value("height_mm").toDouble(465.0),1300.0);
    n.title=o.value("title").toString();n.left=o.value("left").toString();
    n.right=o.value("right").toString();n.date=o.value("date").toString();n.quote=o.value("quote").toString();
    n.topStyle=o.value("top_style").toInt(0);n.leftStyle=o.value("left_style").toInt(0);
    n.rightStyle=o.value("right_style").toInt(0);n.ink=QColor(o.value("ink").toString("#10141b"));
    n.word=o.value("word").toString("MOM").left(16);n.letterStyle=qBound(0,o.value("letter_style").toInt(0),4);
    n.letterFill=qBound(0,o.value("letter_fill").toInt(0),3);
    QDir dir(base);
    for(const auto &x:o.value("photos").toArray()) {
        QJsonObject po=x.toObject();Photo p;p.path=po.value("path").toString();
        if(!p.path.isEmpty() && QFileInfo(p.path).isRelative())p.path=dir.absoluteFilePath(p.path);
        p.mono=po.value("mono").toBool();p.brightness=qBound(-100,po.value("bright").toInt(),100);
        p.contrast=qBound(-100,po.value("contrast").toInt(),100);
        p.zoom=qBound(1.0,po.value("zoom").toDouble(1),5.0);
        p.shiftX=qBound(-1.0,po.value("shift_x").toDouble(),1.0);
        p.shiftY=qBound(-1.0,po.value("shift_y").toDouble(),1.0);
        n.photos.push_back(p);
    }
    n.photos.resize(slots(n).size());d=n;return true;
}
