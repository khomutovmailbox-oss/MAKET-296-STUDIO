#include "window.h"
#include <QApplication>
#include <QCommandLineParser>
#include <QFileInfo>
#include <QFont>
#include <QMessageBox>
#include "renderer.h"
int main(int argc,char *argv[]){
    QApplication app(argc,argv);
    QApplication::setApplicationName("MAKET 296 STUDIO");
    QApplication::setApplicationVersion("6.0");
    QApplication::setOrganizationName("MAKET296");
    QFont font("Segoe UI",10);app.setFont(font);
    QCommandLineParser parser;parser.setApplicationDescription("Qt 6 настольный редактор 296 мм");parser.addHelpOption();
    QCommandLineOption smoke("render-smoke", "Создать тестовый PDF без фото в указанный файл", "path");
    parser.addOption(smoke);parser.process(app);
    if(parser.isSet(smoke)){
        QString err;bool ok=Maket::Renderer::exportFile(parser.value(smoke),Maket::defaultDesign(2),300,&err);
        if(!ok){qCritical("%s",qPrintable(err));return 1;}return 0;
    }
    Maket::MainWindow window;window.show();
    return app.exec();
}
