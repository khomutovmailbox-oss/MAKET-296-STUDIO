#pragma once
#include <QColor>
#include <QJsonObject>
#include <QList>
#include <QPainterPath>
#include <QRectF>
#include <QString>
#include <QVector>

namespace Maket {
constexpr double WidthMm = 296.0;
constexpr double LogicalW = 1000.0;
struct Photo {
    QString path;
    bool mono = false;
    int brightness = 0;
    int contrast = 0;
    double zoom = 1.0;
    double shiftX = 0.0;
    double shiftY = 0.0;
};
struct Design {
    bool letters = false;
    int preset = 2;
    double heightMm = 465.0;
    QVector<Photo> photos;
    QString title = "GIRLFRIEND";
    QString left = "YASHIKA";
    QString right = "VERIKA";
    QString date = "16 09 2006";
    QString quote = "Твой текст";
    int topStyle = 1;
    int leftStyle = 6;
    int rightStyle = 4;
    QColor ink = QColor("#10141b");
    QString word = "MOM";
    int letterStyle = 0;
    int letterFill = 0;
};
struct Slot { QRectF r; int mask = -1; };
struct Preset { int id; QString name; double height; QString title; QString left; QString right; QString date; QString quote; int top; int leftStyle; int rightStyle; };
QVector<Preset> presets();
const Preset* findPreset(int id);
Design defaultDesign(int preset = 2);
QVector<QPainterPath> letterPaths(const Design &d);
QVector<Slot> photoSlots(const Design &d);
QJsonObject toJson(const Design &d, const QString &baseFolder);
bool fromJson(const QJsonObject &obj, const QString &baseFolder, Design &out);
QStringList letterStyleNames();
QStringList fillModeNames();
}
