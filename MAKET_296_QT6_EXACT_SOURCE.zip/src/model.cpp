#include "model.h"
#include <QDir>
#include <QFileInfo>
#include <QFont>
#include <QJsonArray>
#include <QTransform>
#include <QtMath>
#include <algorithm>
using namespace Maket;

QVector<Preset> Maket::presets() {
    return {
        {0, "ONLY YOU · взгляд", 304.880, "ONLY YOU", "", "05 04 2026", "05 04 2026", "", 2, 1, 1},
        {1, "KOROTKOV · мозаика", 424.267, "KOROTKOV", "", "VIOLETTA", "14 05 2026", "", 3, 6, 4},
        {2, "GIRLFRIEND · 8 фото", 464.720, "GIRLFRIEND", "YASHIKA", "VERIKA", "16 09 2006", "", 1, 6, 4},
        {3, "VALERIA · коллаж + силуэт", 424.267, "VALERIA", "", "08 08 2024", "08 08 2024", "", 0, 0, 1},
        {4, "ДОСЬЕ · TOLYA", 213.120, "TOLYA", "", "", "13 02 2006", "", 0, 0, 0},
        {5, "ПОЛАРОИДЫ · 2 фото", 149.973, "", "", "", "", "", 5, 0, 0},
        {6, "ONLY YOU · контур", 291.067, "ONLY YOU", "", "22 07 2025", "22 07 2025", "", 1, 1, 1},
        {7, "YULIYA · коллаж + силуэт", 424.267, "YULIYA", "", "22 03 2026", "22 03 2026", "", 0, 0, 1},
        {8, "ULIANA · двойной монтаж", 1122.827, "GIRLFRIEND", "", "ULIANA", "06 06 2025", "", 1, 1, 3},
        {9, "XOLIDAYBOY · досье", 500.240, "ONLY YOU", "", "ANASTASIA", "", "", 2, 0, 3},
    };
}
const Preset* Maket::findPreset(int id) {
    // Stable storage; do not return pointers into a temporary QVector.
    static const QVector<Preset> all = presets();
    for (const auto &p: all) if (p.id == id) return &p;
    return nullptr;
}
Design Maket::defaultDesign(int preset) {
    Design d;
    if (const auto *p=findPreset(preset)) {
        d.preset=p->id;d.heightMm=p->height;d.title=p->title;d.left=p->left;
        d.right=p->right;d.date=p->date;d.quote=p->quote;d.topStyle=p->top;
        d.leftStyle=p->leftStyle;d.rightStyle=p->rightStyle;
    }
    d.photos.resize(photoSlots(d).size());
    return d;
}
QStringList Maket::letterStyleNames() {
    return {"Impact · массивные", "Arial Black · геометричные", "Arial Rounded · мягкие", "Bahnschrift · узкие", "Georgia · классика"};
}
QStringList Maket::fillModeNames() {
    return {"1 фото на букву", "1 фото через всё слово", "4 фото на букву", "Мозаика через всё слово"};
}
QVector<QPainterPath> Maket::letterPaths(const Design &d) {
    QString word = d.word.trimmed().toUpper().left(16);
    if (word.isEmpty()) word="MOM";
    const QStringList families={"Impact","Arial Black","Arial Rounded MT Bold","Bahnschrift Condensed","Georgia"};
    QFont font(families.value(d.letterStyle,"Impact"));
    font.setWeight(QFont::Black);
    font.setPixelSize(260);
    font.setStyleStrategy(QFont::PreferAntialias);
    const int n=word.size();
    QVector<qreal> widths; qreal total=0;
    for (const auto ch:word) {
        qreal w=(ch==QLatin1Char('I')||ch==QLatin1Char('1')?0.55:
                 QString("MWЖШЩЮФ").contains(ch)?1.17:1.0);
        widths<<w;total+=w;
    }
    if (total<=0) return {};
    const double gap= n>8?4.0:9.0;
    const double space=1000-64-gap*(n-1);
    const double H=1000*d.heightMm/WidthMm;
    const double targetH = std::min(H*.77, 880.0);
    const double top = (H-targetH)/2.0;
    qreal x=32;
    QVector<QPainterPath> result;
    for (int i=0;i<n;++i) {
        qreal cw=space*widths[i]/total;
        QPainterPath native;
        native.addText(QPointF(0,0),font,QString(word[i]));
        QRectF box=native.boundingRect();
        if (!native.isEmpty() && box.width()>0 && box.height()>0) {
            QTransform transform;
            transform.translate(x,top);
            transform.scale((cw*0.97)/box.width(),targetH/box.height());
            transform.translate(-box.left(),-box.top());
            result << transform.map(native);
        } else result<<QPainterPath();
        x+=cw+gap;
    }
    return result;
}
QVector<Slot> Maket::photoSlots(const Design &d) {
    auto R=[&d](double x,double y,double w,double h){return QRectF(1000*x,(1000*d.heightMm/WidthMm)*y,1000*w,(1000*d.heightMm/WidthMm)*h);};
    QVector<Slot> v;
    auto add=[&](double x,double y,double w,double h,int mask=-1){v.push_back({R(x,y,w,h),mask});};
    if (d.letters) {
        const auto glyphs=letterPaths(d);
        if (glyphs.isEmpty()) return v;
        QRectF all;
        for (const auto &path:glyphs) all=all.isNull()?path.boundingRect():all.united(path.boundingRect());
        switch(d.letterFill) {
        case 0:
            for (int i=0;i<glyphs.size();++i) v.push_back({glyphs[i].boundingRect(),i});
            break;
        case 1: v.push_back({all,-2});break;
        case 2:
            for (int i=0;i<glyphs.size();++i) {
                QRectF b=glyphs[i].boundingRect();
                for(int row=0;row<2;row++)for(int col=0;col<2;col++)
                    v.push_back({QRectF(b.left()+col*b.width()/2,b.top()+row*b.height()/2,b.width()/2,b.height()/2),i});
            }
            break;
        case 3: {
            int cols=qBound(3,glyphs.size()*3,16);
            for(int row=0;row<2;row++)for(int col=0;col<cols;col++)
                v.push_back({QRectF(all.left()+col*all.width()/cols,all.top()+row*all.height()/2,all.width()/cols,all.height()/2),-2});
            break;
        }
        default:break;
        }
        return v;
    }
    // Digitized original PDF picture masks, in unchanged 300-point source coordinates.
    struct Frame{int templateId; double x,y,w,h;};
    static const Frame frames[]={
        {0, 0.00000, 0.30421, 1.00000, 0.39482},
        {1, 0.00000, 0.19953, 0.33333, 0.31023},
        {1, 0.66667, 0.48372, 0.33333, 0.27209},
        {1, 0.00000, 0.48349, 0.33333, 0.27256},
        {1, 0.66667, 0.20000, 0.33333, 0.28372},
        {1, 0.33333, 0.20000, 0.33333, 0.17442},
        {1, 0.33333, 0.58140, 0.33333, 0.17442},
        {1, 0.33333, 0.35349, 0.33333, 0.23256},
        {2, 0.33333, 0.47558, 0.33333, 0.26115},
        {2, 0.66667, 0.57537, 0.33333, 0.16136},
        {2, 0.00000, 0.43949, 0.33333, 0.29724},
        {2, 0.00000, 0.17834, 0.33333, 0.26115},
        {2, 0.33333, 0.17834, 0.33333, 0.29724},
        {2, 0.66667, 0.26539, 0.33333, 0.22293},
        {2, 0.66667, 0.48832, 0.33333, 0.08705},
        {2, 0.66667, 0.17813, 0.33333, 0.08747},
        {3, 0.50000, 0.06977, 0.40000, 0.37209},
        {3, 0.10000, 0.06977, 0.40000, 0.37209},
        {3, 0.50000, 0.44186, 0.40000, 0.37442},
        {3, 0.10000, 0.44186, 0.40000, 0.37442},
        {3, 0.21667, 0.30930, 0.58333, 0.53488},
        {4, 0.03667, 0.04167, 0.24000, 0.41667},
        {5, 0.03333, 0.05921, 0.29000, 0.66447},
        {5, 0.47000, 0.05921, 0.29000, 0.66447},
        {6, 0.00000, 0.31119, 1.00000, 0.35051},
        {7, 0.10000, 0.06977, 0.40000, 0.40698},
        {7, 0.50000, 0.40465, 0.40000, 0.40000},
        {7, 0.50000, 0.06977, 0.40000, 0.33488},
        {7, 0.10000, 0.47674, 0.40000, 0.32791},
        {7, 0.07667, 0.23721, 0.68667, 0.60698},
        {8, 0.00000, 0.17645, 0.25000, 0.11722},
        {8, 0.00000, 0.07645, 0.25000, 0.10018},
        {8, 0.75000, 0.17645, 0.25000, 0.11722},
        {8, 0.25000, 0.16081, 0.25000, 0.13269},
        {8, 0.25000, 0.07627, 0.25000, 0.08471},
        {8, 0.75000, 0.07645, 0.25000, 0.10018},
        {8, 0.50000, 0.07645, 0.25000, 0.21705},
        {8, 0.33333, 0.45958, 0.33333, 0.06591},
        {8, 0.66667, 0.56678, 0.33333, 0.12214},
        {8, 0.33333, 0.52548, 0.33333, 0.09754},
        {8, 0.33333, 0.62302, 0.33333, 0.06591},
        {8, 0.00000, 0.56678, 0.33333, 0.12214},
        {8, 0.66667, 0.45958, 0.33333, 0.10721},
        {8, 0.00000, 0.45958, 0.33333, 0.10721},
        {9, 0.00000, 0.25444, 1.00000, 0.17949},
        {9, 0.11000, 0.64497, 0.78000, 0.34320},
    };
    for(const Frame &f:frames){if(d.preset==f.templateId) add(f.x,f.y,f.w,f.h);}
    return v;
}
QJsonObject Maket::toJson(const Design &d,const QString &baseFolder) {
    QJsonObject root{{"format","MAKET296-Qt6"},{"version",1},{"width_mm",WidthMm},
        {"height_mm",d.heightMm},{"letters",d.letters},{"preset",d.preset},
        {"title",d.title},{"left",d.left},{"right",d.right},{"date",d.date},{"quote",d.quote},
        {"top_style",d.topStyle},{"left_style",d.leftStyle},{"right_style",d.rightStyle},
        {"ink",d.ink.name()},{"word",d.word},{"letter_style",d.letterStyle},{"letter_fill",d.letterFill}};
    QJsonArray arr; QDir base(baseFolder);
    for (const auto &p:d.photos) {
        QString src=p.path;
        if (!src.isEmpty() && QFileInfo(src).isAbsolute()) src=base.relativeFilePath(src);
        arr.append(QJsonObject{{"path",src},{"mono",p.mono},{"bright",p.brightness},
            {"contrast",p.contrast},{"zoom",p.zoom},{"shift_x",p.shiftX},{"shift_y",p.shiftY}});
    }
    root["photos"]=arr;return root;
}
bool Maket::fromJson(const QJsonObject &o,const QString &base,Design &d) {
    if (o.value("format").toString()!="MAKET296-Qt6") return false;
    Design n;
    n.letters=o.value("letters").toBool(false);n.preset=o.value("preset").toInt(2);
    if (!findPreset(n.preset)) n.preset=2;
    n.heightMm=qBound(90.0,o.value("height_mm").toDouble(465.0),1300.0);
    n.title=o.value("title").toString();n.left=o.value("left").toString();
    n.right=o.value("right").toString();n.date=o.value("date").toString();n.quote=o.value("quote").toString();
    n.topStyle=o.value("top_style").toInt(0);n.leftStyle=o.value("left_style").toInt(0);
    n.rightStyle=o.value("right_style").toInt(0);n.ink=QColor(o.value("ink").toString("#10141b"));
    n.word=o.value("word").toString("MOM").left(16);n.letterStyle=qBound(0,o.value("letter_style").toInt(0),4);
    n.letterFill=qBound(0,o.value("letter_fill").toInt(0),3);
    QDir dir(base);
    for(const auto &x:o.value("photos").toArray()) {
        QJsonObject po=x.toObject();Photo p;p.path=po.value("path").toString();
        if(!p.path.isEmpty() && QFileInfo(p.path).isRelative())p.path=dir.absoluteFilePath(p.path);
        p.mono=po.value("mono").toBool();p.brightness=qBound(-100,po.value("bright").toInt(),100);
        p.contrast=qBound(-100,po.value("contrast").toInt(),100);
        p.zoom=qBound(1.0,po.value("zoom").toDouble(1),5.0);
        p.shiftX=qBound(-1.0,po.value("shift_x").toDouble(),1.0);
        p.shiftY=qBound(-1.0,po.value("shift_y").toDouble(),1.0);
        n.photos.push_back(p);
    }
    n.photos.resize(photoSlots(n).size());d=n;return true;
}
