#include "window.h"
#include <QApplication>
#include <QCheckBox>
#include <QColorDialog>
#include <QComboBox>
#include <QDir>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFont>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QImageReader>
#include <QJsonDocument>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenuBar>
#include <QMessageBox>
#include <QMimeData>
#include <QMouseEvent>
#include <QPainter>
#include <QPushButton>
#include <QScrollArea>
#include <QScrollBar>
#include <QSignalBlocker>
#include <QSlider>
#include <QSpinBox>
#include <QSplitter>
#include <QStatusBar>
#include <QTabWidget>
#include <QThread>
#include <QTimer>
#include <QIcon>
#include <QUrl>
#include <algorithm>
#include <QPixmap>
#include <QPointer>
#include <QMetaObject>
#include <QToolButton>
#include <QVBoxLayout>
#include <QWheelEvent>
#include <QtMath>
using namespace Maket;
namespace {
const int Margin=24;
QString photosFilter(){return QStringLiteral("Фотографии (*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff);;Все файлы (*.*)");}
QString css(){return QString::fromUtf8(R"QSS(
* { font-family: 'Segoe UI', 'Arial'; font-size: 12px; }
QMainWindow, QWidget#root { background: #151922; color:#e7eaf0; }
QWidget#leftBar, QWidget#rightBar { background:#1b202a; }
QLabel { color:#d5dce5; }
QLabel#muted { color:#93a0b0; font-size:11px; }
QLabel#brand { color:#eff8ff; font-size:21px; font-weight:900; }
QGroupBox { border:1px solid #303a49; border-radius:10px; margin-top:17px; padding:12px 10px 10px; color:#d7e0eb; font-weight:600; }
QGroupBox::title { subcontrol-origin: margin; left:12px; top:1px; padding:0px 6px; }
QLineEdit, QSpinBox, QComboBox { background:#121821; border:1px solid #344052; border-radius:7px; color:#f1f4f8; padding:8px 10px; selection-background-color:#2dbaa3; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border:1px solid #36c6b1; }
QPushButton, QToolButton { background:#293441; border:1px solid #3a4959; border-radius:7px; color:#e6eef7; padding:8px 12px; font-weight:600; }
QPushButton:hover, QToolButton:hover { background:#344453; border-color:#4f7482; }
QPushButton#primary { background:#24a994; border-color:#24a994; color:#071e1c; }
QPushButton#primary:hover { background:#39d3b8; }
QPushButton:disabled { background:#242b35; color:#687482; border-color:#2e3640; }
QSlider::groove:horizontal { height:4px; background:#354455; border-radius:2px; }
QSlider::sub-page:horizontal { background:#22baa4; border-radius:2px; }
QSlider::handle:horizontal { background:#d6fff5; width:14px; margin:-5px 0px; border-radius:7px; }
QCheckBox { spacing:8px; }
QCheckBox::indicator { width:17px; height:17px; }
QListWidget { background:#1b202a; border:none; color:#dce5f0; outline:none; }
QListWidget::item { border:1px solid transparent; padding:9px; margin:4px 2px; border-radius:9px; }
QListWidget::item:hover { background:#293544; }
QListWidget::item:selected { background:#243d3e; border:1px solid #3c9d93; }
QScrollArea { background:#151922; border:0px; }
QScrollBar:vertical { border:0; background:#1b202a; width:9px; }
QScrollBar::handle:vertical { background:#3a495a; border-radius:4px; }
QTabWidget::pane { border:0; }
QTabBar::tab { background:#202734; padding:11px 17px; color:#a7b3c3; border-bottom:2px solid transparent; }
QTabBar::tab:selected { background:#1b202a; color:#e9faf6; border-bottom:2px solid #26c3a8; }
QStatusBar { background:#111720; color:#a2b2c0; }
QToolTip { color:#f5f9ff; background:#263446; border:1px solid #5a6a7c; }
)QSS");}
QLabel* label(const QString &text,bool muted=false){
    auto *l=new QLabel(text);if(muted)l->setObjectName("muted");l->setWordWrap(true);return l;
}
QPushButton* button(const QString &text,QWidget *parent=nullptr,bool primary=false){
    auto *b=new QPushButton(text,parent);if(primary)b->setObjectName("primary");return b;
}
QWidget* wrapVertical(QVBoxLayout *layout){QWidget*w=new QWidget;w->setLayout(layout);return w;}
QSlider* slider(int from,int to,int value){auto*s=new QSlider(Qt::Horizontal);s->setRange(from,to);s->setValue(value);return s;}
}
Canvas::Canvas(QWidget*parent):QWidget(parent){setAcceptDrops(true);setMouseTracking(true);setCursor(Qt::CrossCursor);setAttribute(Qt::WA_OpaquePaintEvent);}
void Canvas::setDesign(Design *d){design_=d;cache_.clear();selected_=-1;refresh();}
void Canvas::setScale(qreal s){scale_=qBound(.18,s,2.6);refresh();}
void Canvas::refresh(){
    if(design_){const QSize target(qRound(LogicalW*scale_+Margin*2),qRound(LogicalW*scale_*design_->heightMm/WidthMm+Margin*2));
        if(size()!=target)setFixedSize(target);}
    update();
}
void Canvas::setSelected(int i){selected_=i;update();emit selectionChanged(i);}
QPointF Canvas::canvasPoint(QPoint pt)const{return QPointF((pt.x()-Margin)/scale_,(pt.y()-Margin)/scale_);}
int Canvas::slotAt(const QPoint &pt)const{
    if(!design_)return -1;auto v=photoSlots(*design_);const QPointF q=canvasPoint(pt);
    QVector<QPainterPath> letters=design_->letters?letterPaths(*design_):QVector<QPainterPath>();
    for(int i=v.size()-1;i>=0;i--){
        if(!v[i].r.contains(q))continue;
        if(design_->letters){
            bool hit=false;
            if(v[i].mask==-2){for(const auto &path:letters)if(path.contains(q)){hit=true;break;}}
            else if(v[i].mask>=0 && v[i].mask<letters.size())hit=letters[v[i].mask].contains(q);
            if(!hit)continue;
        }
        return i;
    }
    return -1;
}
void Canvas::paintEvent(QPaintEvent*){
    QPainter p(this);p.fillRect(rect(),QColor("#151922"));
    if(!design_)return;
    QRectF paper(Margin,Margin,LogicalW*scale_,LogicalW*scale_*design_->heightMm/WidthMm);
    p.setPen(Qt::NoPen);p.setBrush(QColor(0,0,0,80));p.drawRoundedRect(paper.translated(4,6),4,4);
    p.save();p.setClipRect(paper);
    // Transparent checkerboard belongs exclusively to the editor, never exported.
    const int tile=19;
    p.fillRect(paper,QColor("#edf0f3"));
    for(int r=0;r<qCeil(paper.height()/tile);r++)for(int c=0;c<qCeil(paper.width()/tile);c++){
        if((r+c)%2==1)p.fillRect(QRectF(paper.left()+c*tile,paper.top()+r*tile,tile,tile),QColor("#e1e5e9"));
    }
    p.translate(Margin,Margin);p.scale(scale_,scale_);
    Renderer::paint(p,*design_,true,selected_,&cache_);
    p.restore();
    p.setPen(QPen(QColor("#66717c"),.8));p.setBrush(Qt::NoBrush);p.drawRect(paper);
}
void Canvas::mousePressEvent(QMouseEvent*e){
    if(e->button()!=Qt::LeftButton)return;
    int hit=slotAt(e->position().toPoint());setSelected(hit);
    if(hit>=0 && hit<design_->photos.size() && !design_->photos[hit].path.isEmpty()){
        dragStart_=e->position().toPoint();shiftStartX_=design_->photos[hit].shiftX;shiftStartY_=design_->photos[hit].shiftY;dragging_=true;
        setCursor(Qt::ClosedHandCursor);
    }
}
void Canvas::mouseMoveEvent(QMouseEvent*e){
    if(!dragging_ || selected_<0 || !design_)return;
    const auto v=photoSlots(*design_);if(selected_>=v.size())return;
    auto &ph=design_->photos[selected_];
    // Positive mouse movement shifts the content the same way (source crop moves inversely).
    QPointF delta=(e->position().toPoint()-dragStart_);
    ph.shiftX=qBound(-1.0,double(shiftStartX_-delta.x()/std::max(15.0,v[selected_].r.width()*scale_)*2),1.0);
    ph.shiftY=qBound(-1.0,double(shiftStartY_-delta.y()/std::max(15.0,v[selected_].r.height()*scale_)*2),1.0);
    update();
}
void Canvas::mouseReleaseEvent(QMouseEvent*){const bool moved=dragging_;dragging_=false;setCursor(Qt::CrossCursor);if(moved)emit designChanged();}
void Canvas::mouseDoubleClickEvent(QMouseEvent*e){int hit=slotAt(e->position().toPoint());if(hit>=0)emit replaceRequested(hit);}
void Canvas::wheelEvent(QWheelEvent*e){
    if(e->modifiers() & Qt::ControlModifier){emit zoomRequested(e->angleDelta().y());e->accept();return;}
    if(selected_>=0 && design_ && selected_<design_->photos.size() && !design_->photos[selected_].path.isEmpty()){
        auto &ph=design_->photos[selected_];ph.zoom=qBound(1.0,ph.zoom*(e->angleDelta().y()>0?1.065:.939),5.0);
        update();emit designChanged();e->accept();return;
    }
    QWidget::wheelEvent(e);
}
void Canvas::dragEnterEvent(QDragEnterEvent*e){if(e->mimeData()->hasUrls())e->acceptProposedAction();}
void Canvas::dropEvent(QDropEvent*e){
    QStringList paths;
    for(const auto &url:e->mimeData()->urls())if(url.isLocalFile())paths<<url.toLocalFile();
    if(!paths.isEmpty()){emit filesDropped(paths,slotAt(e->position().toPoint()));e->acceptProposedAction();}
}
MainWindow::MainWindow(QWidget*parent):QMainWindow(parent),design_(defaultDesign(2)){
    setWindowTitle("МАКЕТ 296 STUDIO  ·  Qt 6");setMinimumSize(1050,650);resize(1510,900);
    setStyleSheet(css());buildUi();createTemplates();syncControls();
    QTimer::singleShot(80,this,&MainWindow::fitCanvas);
}
void MainWindow::buildUi(){
    QWidget *root=new QWidget;root->setObjectName("root");setCentralWidget(root);
    auto *base=new QVBoxLayout(root);base->setContentsMargins(0,0,0,0);base->setSpacing(0);
    QWidget *header=new QWidget;header->setFixedHeight(64);header->setStyleSheet("background:#101620;");
    auto *hl=new QHBoxLayout(header);hl->setContentsMargins(21,8,21,8);hl->setSpacing(9);
    QLabel *brand=label("M / 296");brand->setObjectName("brand");hl->addWidget(brand);
    auto *subtitle=label("STUDIO   ·   Qt 6 desktop",true);hl->addWidget(subtitle);hl->addStretch(1);
    auto *newButton=button("Новый");hl->addWidget(newButton);
    auto *openButton=button("Открыть проект");hl->addWidget(openButton);
    auto *saveButton=button("Сохранить проект");hl->addWidget(saveButton);
    auto *png=button("PNG",nullptr,true);hl->addWidget(png);
    auto *pdf=button("PDF",nullptr,true);hl->addWidget(pdf);
    auto *svg=button("SVG");hl->addWidget(svg);
    base->addWidget(header);
    QWidget *body=new QWidget;auto *bl=new QHBoxLayout(body);bl->setContentsMargins(0,0,0,0);bl->setSpacing(0);
    left_=new QWidget;left_->setObjectName("leftBar");left_->setFixedWidth(273);
    auto*leftLayout=new QVBoxLayout(left_);leftLayout->setContentsMargins(14,18,14,14);leftLayout->setSpacing(10);
    leftLayout->addWidget(label("БИБЛИОТЕКА",true));
    tabs_=new QTabWidget;
    QWidget *posters=new QWidget;auto *posterLayout=new QVBoxLayout(posters);posterLayout->setContentsMargins(0,13,0,0);
    posterLayout->addWidget(label("Композиции по образцам",true));
    templates_=new QListWidget;templates_->setIconSize(QSize(66,77));templates_->setSpacing(3);
    posterLayout->addWidget(templates_,1);
    tabs_->addTab(posters,"Постеры");
    QWidget *letters=new QWidget;auto *ll=new QVBoxLayout(letters);ll->setContentsMargins(3,18,3,0);ll->setSpacing(10);
    ll->addWidget(label("Введи любое слово",true));wordEdit_=new QLineEdit("MOM");wordEdit_->setMaxLength(16);wordEdit_->setPlaceholderText("MOM, DAD, МАМА, ПАПА…");ll->addWidget(wordEdit_);
    auto*quick=new QHBoxLayout;
    for(const QString &str:QStringList{"MOM","DAD","МАМА","ПАПА"}){
        auto*b=button(str);b->setStyleSheet("padding:5px 2px;");quick->addWidget(b);
        connect(b,&QPushButton::clicked,this,[this,str]{wordEdit_->setText(str);});
    }
    ll->addLayout(quick);ll->addWidget(label("Стиль букв",true));styleCombo_=new QComboBox;styleCombo_->addItems(letterStyleNames());ll->addWidget(styleCombo_);
    ll->addWidget(label("Заполнение фотографиями",true));fillCombo_=new QComboBox;fillCombo_->addItems(fillModeNames());ll->addWidget(fillCombo_);
    ll->addWidget(label("Для заполнения нажми дважды на букву или перетащи фотографии на макет.",true));
    ll->addStretch();tabs_->addTab(letters,"Фото-буквы");
    leftLayout->addWidget(tabs_,1);
    auto *hint=label("Прозрачный фон · ячейки без промежутков\nДвойной клик — заменить фото",true);leftLayout->addWidget(hint);
    bl->addWidget(left_);
    scroller_=new QScrollArea;scroller_->setWidgetResizable(false);scroller_->setAlignment(Qt::AlignHCenter | Qt::AlignTop);
    canvas_=new Canvas;canvas_->setDesign(&design_);scroller_->setWidget(canvas_);bl->addWidget(scroller_,1);
    auto *right=new QWidget;right->setObjectName("rightBar");right->setFixedWidth(311);
    auto *rightScroll=new QScrollArea;rightScroll->setWidgetResizable(true);rightScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);rightScroll->setFixedWidth(311);
    auto *rl=new QVBoxLayout(right);rl->setContentsMargins(16,18,16,18);rl->setSpacing(11);
    rl->addWidget(label("ПАРАМЕТРЫ МАКЕТА",true));
    QWidget *format=new QWidget;auto *formatRow=new QHBoxLayout(format);formatRow->setContentsMargins(0,0,0,0);
    formatRow->addWidget(label("Ширина: 296 мм"));formatRow->addWidget(label("Высота"));
    heightSpin_=new QSpinBox;heightSpin_->setRange(90,1300);heightSpin_->setSuffix(" мм");heightSpin_->setFixedWidth(98);formatRow->addWidget(heightSpin_);rl->addWidget(format);
    auto *photoBox=new QGroupBox("Выбранная фотография");auto *photoLay=new QVBoxLayout(photoBox);
    slotInfo_=label("Выбери фотообласть на макете",true);photoLay->addWidget(slotInfo_);
    fileInfo_=label("Пусто",true);fileInfo_->setTextInteractionFlags(Qt::TextSelectableByMouse);photoLay->addWidget(fileInfo_);
    auto *photoButtons=new QHBoxLayout;
    replaceButton_=button("Заменить фото",nullptr,true);photoButtons->addWidget(replaceButton_);
    removeButton_=button("Очистить");photoButtons->addWidget(removeButton_);photoLay->addLayout(photoButtons);
    auto *addButton=button("+ Загрузить несколько фото");photoLay->addWidget(addButton);
    monoCheck_=new QCheckBox("Чёрно-белая фотография");photoLay->addWidget(monoCheck_);
    photoLay->addWidget(label("Яркость",true));brightSlider_=slider(-100,100,0);photoLay->addWidget(brightSlider_);
    photoLay->addWidget(label("Контраст",true));contrastSlider_=slider(-100,100,0);photoLay->addWidget(contrastSlider_);
    photoLay->addWidget(label("Масштаб фотографии",true));zoomSlider_=slider(100,500,100);photoLay->addWidget(zoomSlider_);
    photoLay->addWidget(label("Перемещение мышью · колесо — масштаб фото · Ctrl+колесо — масштаб холста",true));
    rl->addWidget(photoBox);
    posterOptions_=new QGroupBox("Тексты исходного шаблона");auto *ol=new QFormLayout(posterOptions_);
    titleEdit_=new QLineEdit;leftEdit_=new QLineEdit;rightEdit_=new QLineEdit;dateEdit_=new QLineEdit;quoteEdit_=new QLineEdit;
    topCombo_=new QComboBox;topCombo_->addItems({"Жирный", "Заливка + контур", "Тройной", "Контур + заливка", "Плакат", "Без заголовка"});
    ol->addRow("Заголовок",titleEdit_);ol->addRow("Стиль",topCombo_);
    ol->addRow("Низ слева",leftEdit_);ol->addRow("Низ справа",rightEdit_);
    ol->addRow("Дата",dateEdit_);ol->addRow("Текст",quoteEdit_);
    rl->addWidget(posterOptions_);
    auto *ink=button("Цвет элементов");rl->addWidget(ink);
    rl->addWidget(label("PDF сохраняет векторные буквы и элементы. PNG — прозрачный, 300 dpi. SVG — векторная композиция с растровыми фото.",true));rl->addStretch(1);
    rightScroll->setWidget(right);bl->addWidget(rightScroll);base->addWidget(body,1);
    statusSize_=label("296 мм",true);statusBar()->addPermanentWidget(statusSize_);statusMessage("Готово. Выбери ячейку или перетащи фотографии.");
    connect(templates_,&QListWidget::currentRowChanged,this,[this](int row){if(row>=0 && !loading_){changePreset(templates_->item(row)->data(Qt::UserRole).toInt());}});
    connect(tabs_,&QTabWidget::currentChanged,this,[this](int ix){if(!loading_)switchMode(ix==1);});
    connect(wordEdit_,&QLineEdit::textChanged,this,[this](const QString &s){if(loading_)return;design_.word=s.toUpper();design_.photos.resize(photoSlots(design_).size());canvas_->setSelected(-1);modified();});
    connect(styleCombo_,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this](int n){if(loading_)return;design_.letterStyle=n;design_.photos.resize(photoSlots(design_).size());canvas_->setSelected(-1);modified();});
    connect(fillCombo_,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this](int n){if(loading_)return;design_.letterFill=n;design_.photos.resize(photoSlots(design_).size());canvas_->setSelected(-1);modified();});
    connect(heightSpin_,QOverload<int>::of(&QSpinBox::valueChanged),this,[this](int v){if(loading_)return;design_.heightMm=v;updateSizing();modified();});
    connect(canvas_,&Canvas::selectionChanged,this,&MainWindow::syncPhotoControls);
    connect(canvas_,&Canvas::designChanged,this,[this]{modified();syncPhotoControls();});
    connect(canvas_,&Canvas::replaceRequested,this,[this](int ix){canvas_->setSelected(ix);replacePhoto();});
    connect(canvas_,&Canvas::filesDropped,this,&MainWindow::openPhotos);
    connect(canvas_,&Canvas::zoomRequested,this,[this](int d){setZoom(canvas_->scale()*(d>0?1.10:.91));});
    connect(replaceButton_,&QPushButton::clicked,this,&MainWindow::replacePhoto);
    connect(removeButton_,&QPushButton::clicked,this,[this]{int i=canvas_->selected();if(i>=0 && i<design_.photos.size()){design_.photos[i]=Photo();modified();syncPhotoControls();}});
    connect(addButton,&QPushButton::clicked,this,[this]{QStringList files=QFileDialog::getOpenFileNames(this,"Добавить фотографии",QString(),photosFilter());openPhotos(files,-1);});
    connect(monoCheck_,&QCheckBox::toggled,this,[this](bool v){if(loading_)return;int i=canvas_->selected();if(i>=0){design_.photos[i].mono=v;modified();}});
    connect(brightSlider_,&QSlider::valueChanged,this,[this](int v){if(loading_)return;int i=canvas_->selected();if(i>=0){design_.photos[i].brightness=v;modified();}});
    connect(contrastSlider_,&QSlider::valueChanged,this,[this](int v){if(loading_)return;int i=canvas_->selected();if(i>=0){design_.photos[i].contrast=v;modified();}});
    connect(zoomSlider_,&QSlider::valueChanged,this,[this](int v){if(loading_)return;int i=canvas_->selected();if(i>=0){design_.photos[i].zoom=v/100.0;modified();}});
    auto field=[this](QLineEdit *input,QString Design::*member){connect(input,&QLineEdit::textChanged,this,[this,member](const QString &s){if(loading_)return;design_.*member=s;modified();});};
    field(titleEdit_,&Design::title);field(leftEdit_,&Design::left);field(rightEdit_,&Design::right);field(dateEdit_,&Design::date);field(quoteEdit_,&Design::quote);
    connect(topCombo_,QOverload<int>::of(&QComboBox::currentIndexChanged),this,[this](int i){if(!loading_){design_.topStyle=i;modified();}});
    connect(ink,&QPushButton::clicked,this,[this]{QColor c=QColorDialog::getColor(design_.ink,this,"Цвет текста и декоративных элементов");if(c.isValid()){design_.ink=c;modified();}});
    connect(newButton,&QPushButton::clicked,this,[this]{design_=defaultDesign(design_.preset);projectPath_.clear();canvas_->setDesign(&design_);syncControls();statusMessage("Пустой макет создан");});
    connect(openButton,&QPushButton::clicked,this,&MainWindow::openProject);
    connect(saveButton,&QPushButton::clicked,this,[this]{saveProject();});
    connect(pdf,&QPushButton::clicked,this,[this]{exportAs("pdf");});
    connect(png,&QPushButton::clicked,this,[this]{exportAs("png");});
    connect(svg,&QPushButton::clicked,this,[this]{exportAs("svg");});
}
void MainWindow::createTemplates(){
    loading_=true;
    for(const auto &pr:presets()){
        Design d=defaultDesign(pr.id);
        QImage img=Renderer::preview(d,110);
        QImage preview(110,110,QImage::Format_ARGB32);preview.fill(QColor("#e3e9ee"));
        QPainter p(&preview);p.setRenderHint(QPainter::SmoothPixmapTransform);
        QRectF target(9,4,92,100);QImage scaled=img.scaled(target.size().toSize(),Qt::KeepAspectRatio,Qt::SmoothTransformation);
        p.drawImage(QPointF((110-scaled.width())/2.,(110-scaled.height())/2.),scaled);p.end();
        auto *item=new QListWidgetItem(QIcon(QPixmap::fromImage(preview)),pr.name);
        item->setData(Qt::UserRole,pr.id);item->setSizeHint(QSize(220,93));templates_->addItem(item);
    }
    for(int i=0;i<templates_->count();i++)if(templates_->item(i)->data(Qt::UserRole).toInt()==design_.preset)templates_->setCurrentRow(i);
    loading_=false;
}
void MainWindow::changePreset(int id){
    Design next=defaultDesign(id);
    // Template switch preserves existing photos in matching ordinal positions.
    for(int i=0;i<std::min(next.photos.size(),design_.photos.size());i++)next.photos[i]=design_.photos[i];
    design_=next;canvas_->setDesign(&design_);syncControls();fitCanvas();statusMessage("Загружена композиция: "+findPreset(id)->name);
}
void MainWindow::switchMode(bool letters){
    if(design_.letters==letters)return;
    design_.letters=letters;
    if(letters)design_.heightMm=340;
    else if(const Preset*pr=findPreset(design_.preset))design_.heightMm=pr->height;
    design_.photos.resize(photoSlots(design_).size());canvas_->setSelected(-1);syncControls();fitCanvas();
}
void MainWindow::syncControls(){
    loading_=true;
    tabs_->setCurrentIndex(design_.letters?1:0);
    for(int i=0;i<templates_->count();i++)if(templates_->item(i)->data(Qt::UserRole).toInt()==design_.preset)templates_->setCurrentRow(i);
    wordEdit_->setText(design_.word);styleCombo_->setCurrentIndex(design_.letterStyle);fillCombo_->setCurrentIndex(design_.letterFill);
    heightSpin_->setValue(qRound(design_.heightMm));titleEdit_->setText(design_.title);leftEdit_->setText(design_.left);rightEdit_->setText(design_.right);
    dateEdit_->setText(design_.date);quoteEdit_->setText(design_.quote);topCombo_->setCurrentIndex(design_.topStyle);
    posterOptions_->setVisible(!design_.letters);
    loading_=false;syncPhotoControls();updateSizing();canvas_->refresh();
}
void MainWindow::syncPhotoControls(){
    loading_=true;int i=canvas_->selected();bool valid=i>=0 && i<design_.photos.size();
    slotInfo_->setText(valid?QString("Область № %1 из %2").arg(i+1).arg(design_.photos.size()):"Выбери область на макете");
    fileInfo_->setText(valid?(design_.photos[i].path.isEmpty()?"Место пустое":QFileInfo(design_.photos[i].path).fileName()):"—");
    monoCheck_->setEnabled(valid);brightSlider_->setEnabled(valid);contrastSlider_->setEnabled(valid);zoomSlider_->setEnabled(valid);
    replaceButton_->setEnabled(valid);removeButton_->setEnabled(valid);
    monoCheck_->setChecked(valid && design_.photos[i].mono);
    brightSlider_->setValue(valid?design_.photos[i].brightness:0);
    contrastSlider_->setValue(valid?design_.photos[i].contrast:0);
    zoomSlider_->setValue(valid?qRound(design_.photos[i].zoom*100):100);
    loading_=false;
}
void MainWindow::modified(){canvas_->refresh();updateSizing();}
void MainWindow::setPhoto(int index,const QString &file){
    if(index<0 || index>=design_.photos.size())return;
    QImageReader reader(file);if(!reader.canRead()){statusMessage("Не удалось прочитать: "+QFileInfo(file).fileName());return;}
    design_.photos[index].path=file;design_.photos[index].zoom=1;design_.photos[index].shiftX=0;design_.photos[index].shiftY=0;
    canvas_->setSelected(index);modified();
}
void MainWindow::openPhotos(const QStringList &files,int startIndex){
    if(files.isEmpty())return;
    const int n=design_.photos.size();if(n==0)return;
    int start=startIndex;
    if(start<0){start=canvas_->selected();if(start<0){start=0;while(start<n && !design_.photos[start].path.isEmpty())start++;}}
    for(const auto &file:files){if(start>=n)break;setPhoto(start++,file);}
    statusMessage(QString("Добавлено фотографий: %1").arg(files.size()));
}
void MainWindow::replacePhoto(){
    int selected=canvas_->selected();if(selected<0)return;
    QString file=QFileDialog::getOpenFileName(this,"Выбрать фотографию",QString(),photosFilter());
    if(!file.isEmpty())setPhoto(selected,file);
}
void MainWindow::saveProject(bool as){
    QString path=(!as && !projectPath_.isEmpty())?projectPath_:QFileDialog::getSaveFileName(this,"Сохранить редактируемый проект",projectPath_.isEmpty()?"Мой макет.maket.json":projectPath_,"MAKET проект (*.json)");
    if(path.isEmpty())return;if(!path.endsWith(".json",Qt::CaseInsensitive))path+=".json";
    QFile out(path);if(!out.open(QIODevice::WriteOnly)){QMessageBox::warning(this,"Ошибка",out.errorString());return;}
    out.write(QJsonDocument(toJson(design_,QFileInfo(path).absolutePath())).toJson(QJsonDocument::Indented));out.close();
    projectPath_=path;statusMessage("Проект сохранён: "+QFileInfo(path).fileName());
}
void MainWindow::openProject(){
    QString path=QFileDialog::getOpenFileName(this,"Открыть проект",QString(),"MAKET проекты (*.json)");if(path.isEmpty())return;
    QFile file(path);if(!file.open(QIODevice::ReadOnly)){QMessageBox::warning(this,"Ошибка",file.errorString());return;}
    QJsonParseError err;QJsonDocument json=QJsonDocument::fromJson(file.readAll(),&err);Design d;
    if(err.error!=QJsonParseError::NoError || !fromJson(json.object(),QFileInfo(path).absolutePath(),d)){
        QMessageBox::warning(this,"Ошибка","Невозможно прочитать проект Qt 6.");return;
    }
    design_=d;projectPath_=path;canvas_->setDesign(&design_);syncControls();fitCanvas();statusMessage("Открыт проект: "+QFileInfo(path).fileName());
}
void MainWindow::exportAs(const QString &ext){
    QString suggested=(projectPath_.isEmpty()?"Макет_296":QFileInfo(projectPath_).completeBaseName())+"."+ext;
    QString filter=ext=="png"?"PNG 300 dpi (*.png)":ext=="pdf"?"PDF (*.pdf)":"SVG (*.svg)";
    QString path=QFileDialog::getSaveFileName(this,"Экспорт "+ext.toUpper(),suggested,filter);
    if(path.isEmpty())return;if(!path.endsWith("."+ext,Qt::CaseInsensitive))path+="."+ext;
    Design snapshot=design_;const int dpi=300;
    exportsRunning_++;statusMessage("Создаётся "+ext.toUpper()+"… можно продолжать редактировать");
    QPointer<MainWindow> owner(this);
    QThread *thread=QThread::create([owner,snapshot,path,dpi](){
        QString error;bool ok=Renderer::exportFile(path,snapshot,dpi,&error);
        if(owner)QMetaObject::invokeMethod(owner.data(),[owner,ok,error,path](){
            if(!owner)return;
            owner->exportsRunning_=std::max(0,owner->exportsRunning_-1);
            if(ok)owner->statusMessage("Готово: "+QFileInfo(path).fileName());
            else QMessageBox::warning(owner.data(),"Ошибка экспорта",error);
        },Qt::QueuedConnection);
    });
    connect(thread,&QThread::finished,thread,&QObject::deleteLater);thread->start();
}
void MainWindow::fitCanvas(){
    if(!scroller_ || !canvas_)return;
    double pw=std::max(350,scroller_->viewport()->width()-76);
    double ph=std::max(350,scroller_->viewport()->height()-58);
    double H=LogicalW*design_.heightMm/WidthMm;
    double s=std::min(pw/LogicalW,ph/H);
    setZoom(qBound(.20,s,1.35));
}
void MainWindow::setZoom(double v){canvas_->setScale(v);updateSizing();}
void MainWindow::updateSizing(){if(statusSize_)statusSize_->setText(QString("296 × %1 мм   ·   %2%   ·   %3 фотообластей").arg(design_.heightMm,0,'f',0).arg(qRound(canvas_->scale()*100)).arg(photoSlots(design_).size()));}
void MainWindow::statusMessage(const QString &text){statusBar()->showMessage(text,7000);}
